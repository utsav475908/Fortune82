//
//  ViewController.swift
//  Rockstar
//
//  Created by kuutsav on 5/18/17.
//  Copyright © 2017 kuutsav. All rights reserved.
//

import UIKit
import Rock

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let this = Balboa()
        this.printSome()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

